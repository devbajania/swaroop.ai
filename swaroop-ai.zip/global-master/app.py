from flask import Flask, render_template, request, redirect, url_for, g
import os
import subprocess
import sqlite3
from sqlite3 import Error
import smtplib
from email.message import EmailMessage

import time
from flask import send_from_directory
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'  # Define the upload folder path
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

app.config['result_backend'] = 'redis://localhost:6379/0'


# Ensure the UPLOAD_FOLDER exists
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

CURRENT_PATH = os.path.dirname(os.path.abspath(__file__))

def create_connection(db_file):
    db_path = os.path.join(CURRENT_PATH, db_file)
    conn = None
    try:
        conn = sqlite3.connect(db_path)
    except Error as e:
        print(e)
    return conn

# Database Initialization
conn = create_connection("user_requests.db")
with conn:
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS UserRequests (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            status TEXT NOT NULL,
            video_choice TEXT NOT NULL,
            download_link TEXT
        );
    """)

def send_email(recipient_email, subject, content):
    SMTP_SERVER = "smtp.gmail.com"
    SMTP_PORT = 587
    SMTP_USER = "vivektech245@gmail.com"
    SMTP_PASSWORD = "gevjhgrdysylywds"

    msg = EmailMessage()
    msg.set_content(content)
    msg["Subject"] = subject
    msg["From"] = SMTP_USER
    msg["To"] = recipient_email

    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
        server.starttls()
        server.login(SMTP_USER, SMTP_PASSWORD)
        server.send_message(msg)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']

        conn_local = create_connection("user_requests.db")
        with conn_local:
            cur = conn_local.cursor()
            cur.execute(
                "INSERT INTO UserRequests(name, email, phone, video_choice, status) VALUES(?, ?, ?, ?, 'awaiting photo')",
                (name, email, phone, 'default_video.mp4')
            )
        user_id = cur.lastrowid  # Get the ID of the last inserted record
        queue_number = user_id
        send_email(email, "Registration Confirmation", f"Your queue number is: {queue_number}. We'll notify you once your video is processed.")
        conn_local.close()
        return redirect(url_for('video_select', user_id=user_id))
    return render_template('register.html')

def allowed_file(filename):
    # Check if the filename has an allowed extension
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/video-select', methods=['GET', 'POST'])
def video_select():
    conn = get_db()
    if request.method == 'POST':
        user_id = request.args.get('user_id')
        if not user_id:
            return "Error: User ID not provided!", 400

        video_choice = request.form['video_choice']
        photo = request.files['photo']

        # Check if the uploaded file is an allowed image
        if not allowed_file(photo.filename):
            return "Error: Only image files (png, jpg, jpeg, gif) are allowed!", 400

        photo_path = os.path.join(app.config['UPLOAD_FOLDER'], 'photos', f"{user_id}.jpg")
        photo.save(photo_path)

        with conn:
            cur = conn.cursor()
            cur.execute(
                "UPDATE UserRequests SET video_choice = ?, status = 'not processed' WHERE id = ?", 
                (video_choice, user_id)
            )

        process_single_video.delay(user_id)  # Trigger the new Celery task

        return redirect(url_for('confirmation', user_id=user_id))

    video_dir = os.path.join('static', 'videos')
    video_files = [f for f in os.listdir(video_dir) if os.path.isfile(os.path.join(video_dir, f))]
    return render_template('video_select.html', videos=video_files)

def get_db():
    if 'db' not in g:
        g.db = create_connection("user_requests.db")
    return g.db

@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def generate_queue_number():
    conn_local = create_connection("user_requests.db")
    with conn_local:
        cur = conn_local.cursor()
        cur.execute("SELECT MAX(id) FROM UserRequests")
        max_id = cur.fetchone()[0]
    return max_id + 1 if max_id else 1

@app.route('/confirmation/<int:user_id>', methods=['GET'])
def confirmation(user_id):
    return render_template('confirmation.html', queue_number=user_id)



def process_single_video(self, request_id):
    conn_local = create_connection("user_requests.db")
    with conn_local:
        cur = conn_local.cursor()
        cur.execute("SELECT * FROM UserRequests WHERE id = ?", (request_id,))
        request_data = cur.fetchone()

    if not request_data:
        print(f"No request data found for ID {request_id}.")
        return

    email, video_choice = request_data[2], request_data[4]
    photo_path = os.path.join(app.config['UPLOAD_FOLDER'], 'photos', f"{request_id}.jpg")
    
    if not os.path.exists(photo_path):
        print(f"Error: Photo file {photo_path} does not exist.")
        return

    video_path = os.path.join('static', 'videos', 'video.mp4')
    output_path = os.path.join(app.config['UPLOAD_FOLDER'], 'processed', f"output_{request_id}.mp4")
    roop_command = f'python /home/vivek_m_sangani/NEW_ROOP/roop/run.py --source "{photo_path}" --target "{video_path}" --output "{output_path}" --execution-provider cuda'
    print(f"Executing roop command: {roop_command}")

    try:
        subprocess.run(roop_command, shell=True, check=True)
        with conn_local:
            cur = conn_local.cursor()
            cur.execute(
                "UPDATE UserRequests SET status = 'processed', download_link = ? WHERE id = ?", 
                (output_path, request_id)
            )
        download_link = f"http://35.224.191.173:5000/download/output_{request_id}.mp4"
        send_email(email, "Your Video is Ready!", f"Your processed video is ready! Download it from {download_link}")
        print(f"Video successfully processed for {email}. Request ID: {request_id}. Download link email sent.")
    except subprocess.CalledProcessError as e:
        print(f'Error running Roop: {str(e)}')
        try:
            raise self.retry(exc=e)
        except self.MaxRetriesExceededError:
            print(f"Max retries exceeded for request ID {request_id}.")

def move_temp(target_path, output_path):
    temp_output_path = os.path.join(os.path.dirname(target_path), "temp", "video", "temp.mp4")
    if os.path.exists(temp_output_path):
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        shutil.move(temp_output_path, output_path)
    else:
        print(f"Error: {temp_output_path} does not exist.")

@app.route('/download/<filename>', methods=['GET'])
def download_file(filename):
    directory = os.path.join(CURRENT_PATH, app.config['UPLOAD_FOLDER'], 'processed')
    return send_from_directory(directory, filename, as_attachment=True)

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)
